from django.apps import AppConfig


class UiConfig(AppConfig):
    name = 'ui'
